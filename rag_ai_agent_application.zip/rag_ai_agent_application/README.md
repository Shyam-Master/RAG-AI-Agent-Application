# RAG / AI Agent Application

A backend-focused Retrieval-Augmented Generation (RAG) application that retrieves semantically relevant information from a local knowledge base and uses an LLM to generate context-aware answers.

## Project Overview

The application follows this workflow:

```text
User Question
      ↓
FastAPI API
      ↓
Query Embedding
      ↓
Semantic Retrieval
      ↓
Relevant Context
      ↓
Prompt Construction
      ↓
LLM
      ↓
Context-aware Response
```

The project was built to explore how an LLM can answer questions using external knowledge instead of relying only on its pretrained knowledge.

## Key Features

- FastAPI backend
- Document ingestion from a local `knowledge/` directory
- Text chunking
- Semantic embeddings
- Similarity-based retrieval
- Prompt construction using retrieved context
- LLM response generation
- Simple health-check endpoint
- Clear separation between retrieval and generation logic

## Tech Stack

- Python
- FastAPI
- Sentence Transformers
- NumPy
- OpenAI-compatible LLM API
- Git

## Project Structure

```text
rag-ai-agent-application/
│
├── main.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
└── knowledge/
    └── sample.txt
```

## Setup

### 1. Clone the repository

```bash
git clone <your-repository-url>
cd rag-ai-agent-application
```

### 2. Create a virtual environment

Windows:

```bash
python -m venv .venv
.venv\Scripts\activate
```

Linux/macOS:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure the LLM

Copy `.env.example` to `.env` and add your OpenAI-compatible API configuration.

```env
LLM_API_KEY=your_api_key
LLM_BASE_URL=https://api.openai.com/v1
LLM_MODEL=your_model_name
```

Do not commit `.env` or API keys.

### 5. Add knowledge

Place `.txt` files inside:

```text
knowledge/
```

The application loads these files, splits them into chunks, creates embeddings, and uses them for semantic retrieval.

### 6. Start the API

```bash
uvicorn main:app --reload
```

API:

```text
http://127.0.0.1:8000
```

Swagger documentation:

```text
http://127.0.0.1:8000/docs
```

## API

### Health Check

```http
GET /health
```

Example response:

```json
{
  "status": "ok"
}
```

### Ask a Question

```http
POST /ask
```

Request:

```json
{
  "question": "What information is available in the knowledge base?",
  "top_k": 3
}
```

Response:

```json
{
  "answer": "...",
  "sources": [
    {
      "file": "sample.txt",
      "score": 0.82
    }
  ]
}
```

## Retrieval Approach

The application converts both the knowledge chunks and user query into embedding vectors.

For retrieval:

1. Load knowledge documents.
2. Split documents into manageable chunks.
3. Generate embeddings for each chunk.
4. Generate an embedding for the user query.
5. Calculate cosine similarity.
6. Select the most relevant chunks.
7. Pass the selected context to the LLM.

This helps reduce irrelevant information being passed to the generation stage.

## Agentic RAG Direction

The current implementation provides the core RAG pipeline. The architecture is intentionally separated so that an agentic layer can be added later.

A future agent workflow could:

```text
User Question
      ↓
Agent
      ↓
Decide whether retrieval is required
      ↓
Retrieve knowledge
      ↓
Evaluate retrieved context
      ↓
Retrieve again if necessary
      ↓
Generate final answer
```

This is the direction explored for Agentic RAG systems.

## Challenges

One of the main challenges in RAG systems is retrieval relevance. If irrelevant chunks are retrieved, the LLM can receive poor context and produce a less useful answer.

The project therefore focuses on:

- Semantic rather than exact keyword retrieval
- Chunking knowledge into useful units
- Limiting the amount of retrieved context
- Clear prompt instructions
- Keeping retrieval and generation as separate components

## Future Improvements

- Add a persistent vector database
- Add hybrid keyword + semantic retrieval
- Add reranking
- Add retrieval evaluation
- Add conversation memory
- Add tool calling
- Add an agent planner
- Add streaming responses
- Add authentication and rate limiting
- Add Docker deployment
- Add automated tests and observability

## Interview Summary

> "I built a RAG-based AI application to allow an LLM to answer questions using information from an external knowledge source. I implemented document processing, chunking, embeddings, semantic retrieval, prompt construction and LLM generation behind a FastAPI backend. The main challenge was retrieval relevance because irrelevant context can negatively affect the generated answer. I focused on the retrieval and prompting workflow and designed the architecture so an agentic layer can be added for more adaptive retrieval and tool-based workflows."

## Important Note

This repository describes only technologies and capabilities that are actually implemented. Specific vector databases, agent frameworks, evaluation metrics, or orchestration libraries should only be added to the documentation after they are genuinely used in the code.
