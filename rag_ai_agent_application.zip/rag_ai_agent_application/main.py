import os
from pathlib import Path
from typing import List

import numpy as np
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from sentence_transformers import SentenceTransformer

try:
    from openai import OpenAI
except ImportError:
    OpenAI = None


load_dotenv()

app = FastAPI(
    title="RAG / AI Agent Application",
    description="A lightweight semantic-retrieval RAG backend.",
    version="1.0.0",
)

KNOWLEDGE_DIR = Path("knowledge")
EMBEDDING_MODEL_NAME = os.getenv(
    "EMBEDDING_MODEL",
    "sentence-transformers/all-MiniLM-L6-v2",
)

embedding_model = SentenceTransformer(EMBEDDING_MODEL_NAME)


class DocumentChunk(BaseModel):
    text: str
    source: str


class AskRequest(BaseModel):
    question: str = Field(..., min_length=2)
    top_k: int = Field(default=3, ge=1, le=10)


class Source(BaseModel):
    file: str
    score: float


class AskResponse(BaseModel):
    answer: str
    sources: List[Source]


def load_documents() -> List[DocumentChunk]:
    """Load text files and split them into simple chunks."""
    KNOWLEDGE_DIR.mkdir(exist_ok=True)

    chunks: List[DocumentChunk] = []

    for file_path in sorted(KNOWLEDGE_DIR.glob("*.txt")):
        text = file_path.read_text(encoding="utf-8").strip()

        if not text:
            continue

        # Simple paragraph-based chunking.
        paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]

        for paragraph in paragraphs:
            chunks.append(
                DocumentChunk(
                    text=paragraph,
                    source=file_path.name,
                )
            )

    return chunks


documents = load_documents()

if documents:
    document_embeddings = embedding_model.encode(
        [doc.text for doc in documents],
        normalize_embeddings=True,
    )
else:
    document_embeddings = np.empty((0, 384), dtype=np.float32)


def retrieve(question: str, top_k: int) -> List[tuple[DocumentChunk, float]]:
    """Retrieve the most semantically similar knowledge chunks."""
    if not documents:
        return []

    query_embedding = embedding_model.encode(
        question,
        normalize_embeddings=True,
    )

    scores = np.dot(document_embeddings, query_embedding)
    top_indices = np.argsort(scores)[::-1][:top_k]

    return [
        (documents[index], float(scores[index]))
        for index in top_indices
    ]


def generate_answer(question: str, retrieved: List[tuple[DocumentChunk, float]]) -> str:
    """Generate an answer using an OpenAI-compatible LLM API."""
    api_key = os.getenv("LLM_API_KEY")
    base_url = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")
    model = os.getenv("LLM_MODEL")

    if not retrieved:
        return "I could not find relevant information in the knowledge base."

    context = "\n\n".join(
        f"[Source: {doc.source}]\n{doc.text}"
        for doc, _ in retrieved
    )

    prompt = f"""You are a helpful RAG assistant.

Answer the user's question using only the supplied context.
If the context does not contain enough information, clearly say that
the information is not available in the knowledge base.
Do not invent facts.

Context:
{context}

Question:
{question}
"""

    if not api_key or not model or OpenAI is None:
        # Keeps the backend runnable even before an LLM API is configured.
        return (
            "LLM configuration is not available yet. "
            "The most relevant retrieved context is:\n\n"
            + context
        )

    client = OpenAI(api_key=api_key, base_url=base_url)

    response = client.chat.completions.create(
        model=model,
        messages=[
            {
                "role": "system",
                "content": "Answer questions using the provided retrieval context.",
            },
            {
                "role": "user",
                "content": prompt,
            },
        ],
        temperature=0.2,
    )

    return response.choices[0].message.content or "No answer generated."


@app.get("/health")
def health():
    return {
        "status": "ok",
        "documents_loaded": len(documents),
        "embedding_model": EMBEDDING_MODEL_NAME,
    }


@app.post("/ask", response_model=AskResponse)
def ask(request: AskRequest):
    if not request.question.strip():
        raise HTTPException(status_code=400, detail="Question cannot be empty.")

    retrieved = retrieve(request.question, request.top_k)
    answer = generate_answer(request.question, retrieved)

    sources = [
        Source(file=doc.source, score=round(score, 4))
        for doc, score in retrieved
    ]

    return AskResponse(
        answer=answer,
        sources=sources,
    )
